import { useEffect, useRef, useState } from 'react'

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8080/ws/chat'

export function useChat() {
  const [ws, setWs] = useState(null)
  const [connected, setConnected] = useState(false)
  const [username, setUsername] = useState('')
  const [room, setRoom] = useState('general')
  const [messages, setMessages] = useState([])
  const [users, setUsers] = useState([])

  const pendingLogin = useRef(null)
  const pendingJoin = useRef(null)

  useEffect(() => {
    const socket = new WebSocket(WS_URL)

    socket.onopen = () => {
      setConnected(true)
      pushSystem('Conectado al servidor.')

      if (pendingLogin.current) {
        sendRaw(socket, { type: 'login', username: pendingLogin.current })
        pendingLogin.current = null
      }
      if (pendingJoin.current) {
        sendRaw(socket, { type: 'join', room: pendingJoin.current })
        pendingJoin.current = null
      }
    }

    socket.onclose = () => {
      setConnected(false)
      pushSystem('Desconectado del servidor.')
    }

    socket.onerror = () => {
      pushSystem('Error en la conexión WebSocket.')
    }

    socket.onmessage = event => {
      try {
        const data = JSON.parse(event.data)

        switch (data.type) {
          case 'ok':
            if (data.msg) pushSystem(data.msg)
            break
          case 'error':
            pushSystem('❌ ' + (data.msg || 'Error desconocido'))
            break
          case 'info':
            if (data.text) pushSystem('ℹ️ ' + data.text)
            break
          case 'msg':
            setMessages(prev => [
              ...prev,
              {
                kind: 'user',
                room: data.room,
                from: data.from,
                text: data.text,
              },
            ])
            break
          case 'users':
            if (Array.isArray(data.users)) setUsers(data.users)
            break
          default:
          // ignore
        }
      } catch (e) {
        console.error('Error parseando mensaje', e)
      }
    }

    setWs(socket)
    return () => socket.close()
  }, [])

  function sendRaw(socket, payload) {
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(payload))
    }
  }

  function pushSystem(text) {
    setMessages(prev => [...prev, { kind: 'system', text }])
  }

  function login(name) {
    const trimmed = name.trim()
    if (!trimmed) return

    setUsername(trimmed)

    if (ws && connected && ws.readyState === WebSocket.OPEN) {
      sendRaw(ws, { type: 'login', username: trimmed })
    } else {
      pendingLogin.current = trimmed
    }
  }

  function joinRoom(nextRoom) {
    const trimmed = (nextRoom || '').trim() || 'general'
    setRoom(trimmed)

    if (!username) {
      pushSystem('Primero ingresa un nombre de usuario.')
      return
    }

    if (ws && connected && ws.readyState === WebSocket.OPEN) {
      sendRaw(ws, { type: 'join', room: trimmed })
      sendRaw(ws, { type: 'list', room: trimmed })
    } else {
      pendingJoin.current = trimmed
    }
  }

  function sendMessage(text) {
    const trimmed = text.trim()
    if (!trimmed || !ws || !connected) return
    if (!username) {
      pushSystem('Primero inicia sesión (login).')
      return
    }
    sendRaw(ws, { type: 'msg', room, text: trimmed })
  }

  return {
    connected,
    username,
    room,
    messages,
    users,
    login,
    joinRoom,
    sendMessage,
  }
}
