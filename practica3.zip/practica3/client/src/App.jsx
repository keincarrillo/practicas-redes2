import React, { useState } from 'react'
import { useChat } from './hooks/useChat'

function App() {
  const {
    connected,
    username,
    room,
    messages,
    users,
    login,
    joinRoom,
    sendMessage,
  } = useChat()

  const [nameInput, setNameInput] = useState('')
  const [roomInput, setRoomInput] = useState('general')
  const [msgInput, setMsgInput] = useState('')

  const handleLogin = e => {
    e.preventDefault()
    login(nameInput)
  }

  const handleJoin = e => {
    e.preventDefault()
    joinRoom(roomInput)
  }

  const handleSend = e => {
    e.preventDefault()
    if (!msgInput.trim()) return
    sendMessage(msgInput)
    setMsgInput('')
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      <header className="w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-semibold text-sky-400">Chat Sockets</h1>
            <p className="text-xs text-slate-400">
              Cliente React + Tailwind conectando al servidor Java.
            </p>
          </div>
          <div
            className={
              'px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 ' +
              (connected
                ? 'bg-emerald-500/10 text-emerald-400'
                : 'bg-red-500/10 text-orange-400')
            }
          >
            <span
              className={
                'w-2 h-2 rounded-full ' +
                (connected ? 'bg-emerald-400' : 'bg-red-500')
              }
            />
            {connected ? 'Conectado' : 'Desconectado'}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-4 flex flex-col gap-4">
        {/* Panel superior */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Usuario */}
          <form
            onSubmit={handleLogin}
            className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3 flex flex-col gap-2"
          >
            <h2 className="text-sm font-semibold text-slate-200">
              1. Nombre de usuario
            </h2>
            <input
              type="text"
              className="px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-700 text-xs outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              placeholder="ej. chambeador42"
              value={nameInput}
              onChange={e => setNameInput(e.target.value)}
            />
            <button
              type="submit"
              disabled={!connected}
              className="mt-1 px-3 py-2 rounded-xl text-xs font-medium bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:hover:bg-sky-500 transition-colors"
            >
              {username ? `Cambiar a "${username}"` : 'Iniciar sesión'}
            </button>
            {username && (
              <p className="text-[10px] text-slate-400">
                Actual: <span className="font-semibold">{username}</span>
              </p>
            )}
          </form>

          {/* Sala */}
          <form
            onSubmit={handleJoin}
            className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3 flex flex-col gap-2"
          >
            <h2 className="text-sm font-semibold text-slate-200">2. Sala</h2>
            <input
              type="text"
              className="px-3 py-2 rounded-xl bg-slate-950/80 border border-slate-700 text-xs outline-none focus:ring-2 focus:ring-violet-500 focus:border-violet-500"
              placeholder="general, memes, ayuda..."
              value={roomInput}
              onChange={e => setRoomInput(e.target.value)}
            />
            <button
              type="submit"
              disabled={!connected || !username}
              className="mt-1 px-3 py-2 rounded-xl text-xs font-medium bg-violet-500 hover:bg-violet-400 disabled:opacity-40 disabled:hover:bg-violet-500 transition-colors"
            >
              Unirse / cambiar sala
            </button>
            {room && (
              <p className="text-[10px] text-slate-400">
                En sala: <span className="font-semibold">{room}</span>
              </p>
            )}
          </form>

          {/* Usuarios */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3 flex flex-col gap-2">
            <h2 className="text-sm font-semibold text-slate-200">
              Usuarios en sala
            </h2>
            {users.length === 0 ? (
              <p className="text-[10px] text-slate-500">
                (Se mostrará la lista cuando el servidor envíe el evento
                "users")
              </p>
            ) : (
              <ul className="text-[11px] text-slate-300 space-y-1">
                {users.map(u => (
                  <li key={u} className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full" />
                    {u}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Chat */}
        <section className="flex-1 flex flex-col bg-slate-900/70 border border-slate-800 rounded-2xl overflow-hidden">
          {/* Mensajes */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-1 text-sm">
            {messages.map((m, i) =>
              m.kind === 'system' ? (
                <div
                  key={i}
                  className="text-[10px] text-slate-500 italic select-none"
                >
                  {m.text}
                </div>
              ) : (
                <div key={i} className="flex flex-col">
                  <span className="text-[10px] text-sky-400">
                    [{m.room}] {m.from}
                  </span>
                  <span className="text-slate-100 text-xs">{m.text}</span>
                </div>
              )
            )}
          </div>

          {/* Barra de envío */}
          <form
            onSubmit={handleSend}
            className="border-t border-slate-800 px-4 py-3 flex items-center gap-2 bg-slate-950/70"
          >
            <input
              type="text"
              className="flex-1 px-4 py-2 rounded-full bg-slate-900 border border-slate-700 text-xs text-slate-100 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              placeholder={
                !connected
                  ? 'Conectando al servidor...'
                  : !username
                  ? 'Primero ingresa tu nombre de usuario...'
                  : !room
                  ? 'Elige una sala para chatear...'
                  : 'Escribe tu mensaje y presiona Enter'
              }
              value={msgInput}
              onChange={e => setMsgInput(e.target.value)}
              disabled={!connected || !username || !room}
            />
            <button
              type="submit"
              disabled={
                !connected || !username || !room || !msgInput.trim().length
              }
              className="px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 text-xs font-semibold text-slate-950 disabled:opacity-40 disabled:hover:bg-emerald-500 transition-colors"
            >
              Enviar
            </button>
          </form>
        </section>
      </main>
    </div>
  )
}

export default App
