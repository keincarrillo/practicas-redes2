package com.example.server.core;

import org.springframework.web.socket.WebSocketSession;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ChatState {

    private final Map<String, InetSocketAddress> udpUsers = new ConcurrentHashMap<>();

    private final Map<WebSocketSession, String> wsUsers = new ConcurrentHashMap<>();

    private final Map<String, Set<String>> rooms = new ConcurrentHashMap<>();

    public void loginUdp(String username, InetSocketAddress addr) {
        udpUsers.put(username, addr);
    }

    public String findUdpUser(InetSocketAddress addr) {
        for (var e : udpUsers.entrySet()) {
            if (e.getValue().equals(addr)) {
                return e.getKey();
            }
        }
        return null;
    }

    public InetSocketAddress udpAddrFor(String username) {
        return udpUsers.get(username);
    }

    public void loginWs(WebSocketSession session, String username) {
        wsUsers.put(session, username);
    }

    public String usernameForWs(WebSocketSession session) {
        return wsUsers.get(session);
    }

    public void removeWs(WebSocketSession session) {
        String user = wsUsers.remove(session);
        if (user != null) {
            rooms.values().forEach(set -> set.remove(user));
        }
    }

    public Collection<WebSocketSession> allWsSessions() {
        return wsUsers.keySet();
    }

    public void joinRoom(String username, String room) {
        rooms
                .computeIfAbsent(room, r -> ConcurrentHashMap.newKeySet())
                .add(username);
    }

    public Set<String> usersOfRoom(String room) {
        return rooms.getOrDefault(room, Set.of());
    }

    public List<String> usersInRoom(String room) {
        return new ArrayList<>(usersOfRoom(room));
    }
}
