package com.example.server.ws;

import com.example.server.core.ChatState;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Protocolo WS (JSON):
 *
 * C -> S:
 *  {"type":"login","username":"pepe"}
 *  {"type":"join","room":"general"}
 *  {"type":"msg","room":"general","text":"hola"}
 *  {"type":"list","room":"general"}
 *
 * S -> C:
 *  {"type":"ok","msg":"..."}
 *  {"type":"error","msg":"..."}
 *  {"type":"info","text":"..."}
 *  {"type":"msg","room":"general","from":"pepe","text":"hola"}
 *  {"type":"users","room":"general","users":["pepe","ana"]}
 */
@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {

    private final ChatState state;
    private final ObjectMapper mapper = new ObjectMapper();

    public ChatWebSocketHandler(ChatState state) {
        this.state = state;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        System.out.println("[WS] Conectado: " + session.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message)
            throws IOException {

        Map<String, Object> data = mapper.readValue(message.getPayload(), Map.class);
        String type = (String) data.get("type");

        switch (type) {
            case "login" -> handleLogin(session, data);
            case "join"  -> handleJoin(session, data);
            case "msg"   -> handleMsg(session, data);
            case "list"  -> handleList(session, data);
            default      -> sendError(session, "Tipo desconocido: " + type);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        state.removeWs(session);
        System.out.println("[WS] Cerrado: " + session.getId());
    }

    // ===== Handlers =====

    private void handleLogin(WebSocketSession session, Map<String, Object> data) throws IOException {
        String username = (String) data.get("username");
        if (username == null || username.isBlank()) {
            sendError(session, "Username requerido");
            return;
        }
        state.loginWs(session, username);
        send(session, Map.of("type", "ok", "msg", "Bienvenido " + username));
    }

    private void handleJoin(WebSocketSession session, Map<String, Object> data) throws IOException {
        String room = (String) data.get("room");
        String user = state.usernameForWs(session);
        if (user == null) {
            sendError(session, "Haz login primero");
            return;
        }
        if (room == null || room.isBlank()) {
            sendError(session, "Room requerida");
            return;
        }
        state.joinRoom(user, room);
        broadcast(Map.of("type", "info", "text", user + " se unió a " + room));
        sendUsers(session, room);
    }

    private void handleMsg(WebSocketSession session, Map<String, Object> data) throws IOException {
        String room = (String) data.get("room");
        String text = (String) data.get("text");
        String user = state.usernameForWs(session);

        if (user == null) {
            sendError(session, "Haz login primero");
            return;
        }
        if (room == null || text == null || room.isBlank() || text.isBlank()) {
            sendError(session, "room y text son requeridos");
            return;
        }

        broadcast(Map.of(
                "type", "msg",
                "room", room,
                "from", user,
                "text", text
        ));
    }

    private void handleList(WebSocketSession session, Map<String, Object> data) throws IOException {
        String room = (String) data.get("room");
        sendUsers(session, room);
    }

    // ===== Utilidades =====

    private void send(WebSocketSession s, Map<String, ?> payload) throws IOException {
        if (s.isOpen()) {
            s.sendMessage(new TextMessage(mapper.writeValueAsString(payload)));
        }
    }

    private void sendError(WebSocketSession s, String msg) throws IOException {
        send(s, Map.of("type", "error", "msg", msg));
    }

    private void sendUsers(WebSocketSession s, String room) throws IOException {
        if (room == null || room.isBlank()) {
            sendError(s, "Room requerida para listar usuarios");
            return;
        }
        List<String> users = state.usersInRoom(room);
        send(s, Map.of(
                "type", "users",
                "room", room,
                "users", users
        ));
    }

    private void broadcast(Map<String, ?> payload) throws IOException {
        String json = mapper.writeValueAsString(payload);
        TextMessage msg = new TextMessage(json);
        for (WebSocketSession s : state.allWsSessions()) {
            if (s.isOpen()) {
                s.sendMessage(msg);
            }
        }
    }
}
