package com.example.server.udp;

import com.example.server.core.ChatState;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

@Component
public class UdpChatServer {

    private final ChatState state;
    private final int port = 5000;

    public UdpChatServer(ChatState state) {
        this.state = state;
    }

    @PostConstruct
    public void start() {
        Thread t = new Thread(this::runServer, "UdpChatServer");
        t.setDaemon(true);
        t.start();
    }

    private void runServer() {
        try (DatagramSocket socket = new DatagramSocket(port)) {
            System.out.println("[UDP] Escuchando en puerto " + port);
            byte[] buf = new byte[4096];

            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                String msg = new String(
                        packet.getData(),
                        0,
                        packet.getLength(),
                        StandardCharsets.UTF_8
                ).trim();

                InetSocketAddress from = new InetSocketAddress(
                        packet.getAddress(),
                        packet.getPort()
                );

                handle(socket, msg, from);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void send(DatagramSocket socket, InetSocketAddress to, String msg) {
        try {
            byte[] data = msg.getBytes(StandardCharsets.UTF_8);
            DatagramPacket packet = new DatagramPacket(
                    data, data.length, to.getAddress(), to.getPort()
            );
            socket.send(packet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void broadcastRoom(DatagramSocket socket, String room, String msg) {
        for (String u : state.usersOfRoom(room)) {
            InetSocketAddress addr = state.udpAddrFor(u);
            if (addr != null) {
                send(socket, addr, msg);
            }
        }
    }

    private void handle(DatagramSocket socket, String msg, InetSocketAddress from) {
        String[] parts = msg.split("\\|", 3);
        String cmd = parts[0];

        switch (cmd) {
            case "LOGIN" -> {
                if (parts.length < 2) {
                    send(socket, from, "ERROR|Falta username");
                    return;
                }
                String username = parts[1];
                state.loginUdp(username, from);
                send(socket, from, "OK|Bienvenido " + username);
            }
            case "JOIN" -> {
                if (parts.length < 2) {
                    send(socket, from, "ERROR|Falta room");
                    return;
                }
                String room = parts[1];
                String user = state.findUdpUser(from);
                if (user == null) {
                    send(socket, from, "ERROR|Haz LOGIN primero");
                    return;
                }
                state.joinRoom(user, room);
                broadcastRoom(socket, room, "INFO|" + user + " se unió a " + room);
            }
            case "MSG" -> {
                if (parts.length < 3) {
                    send(socket, from, "ERROR|Formato MSG|room|texto");
                    return;
                }
                String room = parts[1];
                String text = parts[2];
                String user = state.findUdpUser(from);
                if (user == null) {
                    send(socket, from, "ERROR|Haz LOGIN primero");
                    return;
                }
                broadcastRoom(socket, room, "MSG|" + room + "|" + user + "|" + text);
            }
            case "LIST" -> {
                if (parts.length < 2) {
                    send(socket, from, "ERROR|Formato LIST|room");
                    return;
                }
                String room = parts[1];
                var users = String.join(",", state.usersInRoom(room));
                send(socket, from, "USERS|" + room + "|" + users);
            }
            default -> send(socket, from, "ERROR|Comando no reconocido");
        }
    }
}
